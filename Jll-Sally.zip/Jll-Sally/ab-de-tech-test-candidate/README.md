## Stack
- **postgres** — one Postgres instance, two databases: `airflow` (metadata) and `financials` (target data).
- **airflow** — single container running `airflow standalone` (webserver + scheduler + triggerer), `LocalExecutor`, pointed at the `airflow` database. No login required (`AUTH_ROLE_PUBLIC=Admin` in `webserver_config.py`).
- **pgweb** — lightweight web UI connected directly to the `financials` database: browse tables/schema and run ad-hoc SQL from the browser. No login required (connection is pre-wired via `PGWEB_DATABASE_URL`).

## Run it
```bash
docker compose up -d --build
```

- Airflow UI: http://localhost:8080 (opens straight in, no login)
- pgweb: http://localhost:8081 (opens straight in, already connected to `financials`, no login) — browse tables under **Rows**/**Structure**, or write ad-hoc SQL under the **Query** tab.

## Credentials
Nothing needs a login, but if you ever connect to Postgres directly (`psql`, DBeaver, pgweb's own "Connection" tab, etc.), the database credentials are all set in `docker-compose.yml`:
- User: `airflow` / Password: `airflow`
- Host: `postgres` from inside the Docker network, `localhost` from your host machine (port 5432 is published)
- Databases: `airflow` (Airflow's own metadata) and `financials` (the rent roll data pgweb and the DAG both use)

Trigger the `load_financials` DAG from the UI (or `docker compose exec airflow airflow dags trigger load_financials`). It will:
1. Create the `rent_roll` and `portfolio_walt` tables in the `financials` database.
2. Load `data/rent_roll.xlsx` into `rent_roll`.
3. Compute per-unit `remaining_term_years` (written back onto `rent_roll`) and portfolio-level WALT (area-weighted and income-weighted, written to `portfolio_walt`).

Example queries once the DAG has run (paste into pgweb's Query tab):
```sql
SELECT * FROM portfolio_walt;
SELECT property_name, tenant_name, area_sf, remaining_term_years
FROM rent_roll
ORDER BY remaining_term_years DESC
LIMIT 10;
```

## WALT methodology
- `as_of` date defaults to the DAG run's execution date; pass `{"as_of_date": "YYYY-MM-DD"}` as DAG run config to pin it (e.g. to the rent roll's export date, 2025-10-29, for reproducible numbers regardless of when the DAG is actually run).
- Vacant units (`tenant_name = 'AVAILABLE'`) and rows with no lease end date or zero area are excluded from the WALT calculation.
- Expired/holdover leases (lease end in the past relative to `as_of`) contribute 0 remaining years rather than a negative number.
- Area-weighted WALT = Σ(remaining_term_years × area_sf) / Σ(area_sf).
- Income-weighted WALT = Σ(remaining_term_years × base_rent_annual) / Σ(base_rent_annual).
