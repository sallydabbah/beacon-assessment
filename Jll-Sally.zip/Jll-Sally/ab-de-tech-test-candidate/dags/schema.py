"""Table definitions for the financials database, shared by the load_financials DAG."""

from sqlalchemy import (
    Boolean,
    Column,
    Date,
    Integer,
    MetaData,
    Numeric,
    Table,
    Text,
    TIMESTAMP,
    func,
)

metadata = MetaData()

rent_roll = Table(
    "rent_roll",
    metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("property_name", Text),
    Column("beacon_asset_id", Text),
    Column("tenant_name", Text),
    Column("unit", Text),
    Column("unit_type", Text),
    Column("unit_class", Text),
    Column("area_sf", Numeric(12, 2)),
    Column("lease_start", Date),
    Column("lease_end", Date),
    Column("is_m2m", Boolean),
    Column("base_rent_psf", Numeric(10, 2)),
    Column("base_rent_annual", Numeric(14, 2)),
    Column("recovery_type", Text),
    Column("additional_rent_psf", Numeric(10, 2)),
    Column("remaining_term_years", Numeric(10, 4)),
)

portfolio_walt = Table(
    "portfolio_walt",
    metadata,
    Column("as_of_date", Date, primary_key=True),
    Column("walt_area_weighted_years", Numeric(10, 4)),
    Column("walt_income_weighted_years", Numeric(10, 4)),
    Column("included_unit_count", Integer),
    Column("excluded_unit_count", Integer),
    Column("computed_at", TIMESTAMP, server_default=func.now()),
)
