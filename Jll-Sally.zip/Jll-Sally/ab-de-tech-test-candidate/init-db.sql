CREATE DATABASE financials;
