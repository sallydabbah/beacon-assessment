from __future__ import annotations

import logging
from datetime import datetime

import pandas as pd
from airflow.decorators import dag, task
from airflow.operators.python import get_current_context
from airflow.providers.postgres.hooks.postgres import PostgresHook
from sqlalchemy import text

from schema import metadata


logger = logging.getLogger(__name__)

RENT_ROLL_PATH = "/opt/airflow/data/rent_roll.xlsx"
SHEET_NAME = "Rent Roll - Units"
CONN_ID = "financials_db"

COLUMNS = [
    "property_name",
    "beacon_asset_id",
    "tenant_name",
    "unit",
    "unit_type",
    "unit_class",
    "area_sf",
    "lease_start",
    "lease_end",
    "is_m2m",
    "base_rent_psf",
    "base_rent_annual",
    "recovery_type",
    "additional_rent_psf",
]

@dag(
    dag_id="load_financials",
    schedule=None,
    start_date=datetime(2025, 1, 1),
    catchup=False,
    tags=["financials", "rent-roll"],
)
def load_financials():
    @task
    def create_tables() -> None:
        # rent_roll / portfolio_walt column definitions live in schema.py
        """
        Create the rent_roll and portfolio_walt tables defined in schema.py.
        """
        hook = PostgresHook(postgres_conn_id=CONN_ID)
        engine = hook.get_sqlalchemy_engine()
        metadata.create_all(engine, checkfirst=True)
        logger.info("Database tables created or verified successfully.") #added log to confirm table creation

    @task
    def extract_load() -> int:
        # The sheet has a 3-row merged header (group label / sub-label / unit-of-measure),
        # so we skip it entirely and supply our own column names rather than fight pandas'
        # multi-row header handling.
        """
        Read the rent roll Excel sheet, clean the values, and perform
        a full refresh of the rent_roll table.
        """
        df = pd.read_excel(
            RENT_ROLL_PATH,
            sheet_name=SHEET_NAME,
            usecols="B:O",
            skiprows=9,
            header=None,
            names=COLUMNS,
        )

        logger.info("Read %s rows from the rent roll workbook.", len(df))

        # Remove completely empty rows.
        df = df.dropna(how="all").copy()

        # Normalize string columns.
        string_columns = [
            "property_name",
            "beacon_asset_id",
            "tenant_name",
            "unit",
            "unit_type",
            "unit_class",
            "recovery_type",
        ]

        for column in string_columns:
            df[column] = df[column].astype("string").str.strip()

        # Convert Excel/text dates to pandas timestamps.
        df["lease_start"] = pd.to_datetime(df["lease_start"],format="%b %d, %Y", errors="coerce")
        df["lease_end"] = pd.to_datetime(df["lease_end"],format="%b %d, %Y",errors="coerce")

        # Nullable boolean dtype so blank cells stay NULL instead of being coerced to True/False.
        # Sally: astype(bool) uses the standard Python/pandas boolean conversion and does not preserve missing values as nullable booleans.
        df["is_m2m"] = df["is_m2m"].astype("boolean")

        # SQLAlchemy/PostgreSQL accepts Python None more reliably than pd.NA.
        df = df.astype(object).where(pd.notna(df), None)

        hook = PostgresHook(postgres_conn_id=CONN_ID)
        engine = hook.get_sqlalchemy_engine()

        # Full refresh. The operation is performed in one transaction.
        # Sally:
        # changed the full-refresh load so the TRUNCATE and insert run in the same transaction. That way, if the insert fails, the transaction rolls back instead of potentially leaving rent_roll empty.
        # passed connection to to_sql so that the insert runs in the same transaction as the truncate instead of engine.begin() creating a new transaction for the insert. This way, if the insert fails, the transaction rolls back instead of potentially leaving rent_roll empty.
        with engine.begin() as connection:
            connection.execute(
                text("TRUNCATE TABLE rent_roll RESTART IDENTITY")
            )

            df.to_sql(
                "rent_roll",
                connection,
                if_exists="append",
                index=False,
                method="multi",
                chunksize=500,
            )

        logger.info("Loaded %s rows into rent_roll.", len(df))

        return len(df)

    @task
    def calculate_walt(as_of_date: str | None = None) -> dict:
        
        context = get_current_context()
        dag_run = context.get("dag_run")
        # as_of defaults to today; pass {"as_of_date": "YYYY-MM-DD"} via DAG run config to pin it.
        # sally: question: why you asked to default to today? i think this will make the data "unclean" we should have a dedicated column called: dag_run_date or something rather than using current date and modify it 
        # it will cause DataQuality issues..Btw no DQ handling is done in this DAG(we should do it in a seperate task before the calculation)..
        if as_of_date is None and dag_run is not None:
            as_of_date = dag_run.conf.get("as_of_date")

        if as_of_date:
            as_of = pd.Timestamp(as_of_date).normalize() # "2026-10-10" becomes: "2026-10-10 00:00:00"
        else:
            as_of = pd.Timestamp.utcnow().tz_localize(None).normalize() # get today's UTC date and ignore the current time.
        # Vacant units and rows with no lease end date or no area don't have a lease term
        # to contribute, so they're excluded from the WALT weighting entirely.
        hook = PostgresHook(postgres_conn_id=CONN_ID)
        engine = hook.get_sqlalchemy_engine()
        
        df = pd.read_sql(text("SELECT * FROM rent_roll"),engine)
        if df.empty:
            raise ValueError("The rent_roll table contains no rows.")

        df["lease_end"] = pd.to_datetime(df["lease_end"],errors="coerce")
        df["area_sf"] = pd.to_numeric(df["area_sf"],errors="coerce")
        df["base_rent_annual"] = pd.to_numeric(
        df["base_rent_annual"],errors="coerce")
        #Normalize tenant_name to uppercase and strip whitespace for comparison.
        tenant_name = (
            df["tenant_name"]
            .fillna("")
            .astype(str)
            .str.strip()
            .str.upper()
        )

        # Exclude vacant units, expired/missing leases, and rows with no area.- occupied units that have a valid lease end date and positive area, and put them into valid.
        valid = df[
            tenant_name.ne("AVAILABLE")
            & df["lease_end"].notna()
            & df["area_sf"].gt(0)
        ].copy()

        #Sally: I added this check to make sure we don't divide by zero later on. If there are no valid units, we should raise an error.
        if valid.empty:
            raise ValueError(
                "No eligible occupied units were found for WALT calculation."
            )
        
        # WALT is conventionally expressed in years, not days, so the remaining lease
        # term needs converting before it's used as a weight below.
        remaining_days = (valid["lease_end"] - as_of).dt.days.clip(lower=0)

        # Convert days to years.
        valid["remaining_term_years"] = remaining_days / 365.25
        total_area = valid["area_sf"].sum()

        #Sally: contains only rows from valid where there is a positive annual rent value.
        income_valid = valid[valid["base_rent_annual"].notna() & valid["base_rent_annual"].gt(0)].copy()
        total_income = income_valid["base_rent_annual"].sum()

        if total_area <= 0:
            raise ValueError("Total eligible area must be greater than zero.")

        if income_valid.empty or total_income <= 0:
            raise ValueError("Total eligible annual rent must be greater than zero.")
        # Area-weighted: each lease's remaining term weighted by how much space it occupies.
        walt_area = (valid["remaining_term_years"] * valid["area_sf"] ).sum() / total_area
        walt_income = (income_valid["remaining_term_years"] * income_valid["base_rent_annual"]).sum() / total_income

        #we need it in the view calculations so ideally in Silver layer we should have a column called remaining_term_years and we should populate it here.
        update_rows = [
            {
                "remaining_term_years": round(float(term), 4),
                "row_id": int(row_id),
            }
            for term, row_id in zip(
                valid["remaining_term_years"],
                valid["id"],
            )
        ]

        #write back to rentroll 
        with engine.begin() as connection:
            connection.execute(
                text("""
                    UPDATE rent_roll
                    SET remaining_term_years = :remaining_term_years
                    WHERE id = :row_id
                """),
                update_rows,
            )

        #Sally : packages the final WALT calculation results into one object and then its inserted into the portfolio_walt table. This is done in a single transaction to ensure data integrity.
        summary_parameters = {
            "as_of_date": as_of.date(),
            "walt_area": round(float(walt_area), 4),
            "walt_income": round(float(walt_income), 4),
            "included_count": int(len(valid)),
            "excluded_count": int(len(df) - len(valid)),
        }

        with engine.begin() as connection:
            # Reset all unit-level calculated values before updating eligible
            # units. This prevents stale values if eligibility changes.
            #Sally: removes potentially stale calculated values, for example if a unit is Available that means it shold have remaining_term_years as Null 
            #Sally: i dont like this approach, it would be better to have a separate table for the calculated values instead of having them in the rent_roll table.
            # This way we can avoid the risk of accidentally deleting or updating important data in the rent_roll table.
            #  We can create a new table called rent_roll_calculated that will store the calculated values for each unit. T
            #  his way we can keep the original rent_roll table intact and only update the calculated values in the new table. -
            # and regarding stale data,we can have a seperate task that will check for stale data and update the calculated values accordingly. This way we can ensure that the calculated values are always up to date and accurate.
            # we are not maintaing historical data here, we are just calculating the current WALT based on the current rent_roll data
            connection.execute(
                text(
                    """
                    UPDATE rent_roll
                    SET remaining_term_years = NULL
                    """
                )
            )
            # Push each unit's remaining term back onto rent_roll so it's queryable
            # alongside the raw lease data, not just in the portfolio-level summary.
            if update_rows:
                connection.execute(
                    text(
                        """
                        UPDATE rent_roll
                        SET remaining_term_years = :remaining_term_years
                        WHERE id = :row_id
                        """
                    ),
                    update_rows,
                )
            # Delete and insert makes same-day reruns idempotent,overwrites the previous WALT calculation if the DAG is re-run for the same as_of_date
            connection.execute(
                text(
                    """
                    DELETE FROM portfolio_walt
                    WHERE as_of_date = :as_of_date
                    """
                ),
                {"as_of_date": as_of.date()},
            )

            connection.execute(
                text(
                    """
                    INSERT INTO portfolio_walt (
                        as_of_date,
                        walt_area_weighted_years,
                        walt_income_weighted_years,
                        included_unit_count,
                        excluded_unit_count
                    )
                    VALUES (
                        :as_of_date,
                        :walt_area,
                        :walt_income,
                        :included_count,
                        :excluded_count
                    )
                    """
                ),
                summary_parameters,
            )

        logger.info("WALT area-weighted: %.2f years",walt_area)
        logger.info("WALT income-weighted: %.2f years",walt_income)
        logger.info(
            "Included units: %s; excluded units: %s",
            len(valid),
            len(df) - len(valid) # not ideal for big data TB's (its only for the sake of the POC)
        )
        return summary_parameters

    @task
    def create_property_view() -> None:
        """
        Create a queryable per-property WALT view after the calculated
        remaining lease terms have been stored in rent_roll.
        """
        hook = PostgresHook(postgres_conn_id=CONN_ID)

        hook.run(
            """
            CREATE OR REPLACE VIEW walt_by_property AS
            SELECT
                property_name,

                SUM(remaining_term_years * area_sf)
                    / NULLIF(SUM(area_sf), 0)
                    AS walt_area_weighted_years,

                SUM(remaining_term_years * base_rent_annual)
                    / NULLIF(SUM(base_rent_annual), 0)
                    AS walt_income_weighted_years,

                COUNT(*) AS included_unit_count,

                SUM(area_sf) AS included_area_sf,

                SUM(base_rent_annual) AS included_annual_rent

            FROM rent_roll
            WHERE remaining_term_years IS NOT NULL
              AND area_sf > 0
              AND UPPER(COALESCE(tenant_name, '')) <> 'AVAILABLE'
            GROUP BY property_name
            """
        )

        logger.info("calculated walt_by_property view")

    create_tables() >> extract_load() >> calculate_walt() >> create_property_view()


load_financials()